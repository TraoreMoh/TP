# Chargement des packages

library(tidyverse)
library(readxl)
library(questionr)
library(expss)
library(labelled)
# Importation et mise en forme

base_tp2 <- read_excel("Données/Base TP2.xlsx")
View(base_tp2)

# Le nombre de ligne et de colonne de la base

nb_lignes <- nrow(base_tp2)
nb_colonnes <- ncol(base_tp2)
cat("Nombre de lignes de la base est :", nb_lignes, "\n")
cat("Nombre de colonnes de la base est :", nb_colonnes, "\n")

# Recodage et labellisation

irec(base_tp2$sexe)

## Recodage de base_tp2$sexe en base_tp2$sexe_rec
base_tp2$sexe <- base_tp2$sexe %>%
  as.character() %>%
  fct_recode(
    "Homme" = "1",
    "Femme" = "2"
  )

base_tp2$sexe <-
    recode_factor(base_tp2$sexe,
    "1" = "Homme",
    "2" = "Femme"
  )



base_tp2$sexe
irec(base_tp2$sit_mat)
## Recodage de base_tp2$sit_mat en base_tp2$sit_mat_rec
base_tp2$sit_mat <- base_tp2$sit_mat %>%
  as.character() %>%
  fct_recode(
    "Marié(e)" = "1",
    "Veuf(ve)" = "3",
    "Divorcé(e)" = "4",
    "Séparé(e)" = "5",
    "Célibataire" = "6"
  )
levels(base_tp2$sit_mat)

irec(base_tp2$si_chef_men)
## Recodage de base_tp2$si_chef_men en base_tp2$si_chef_men_rec
base_tp2$si_chef_men <- base_tp2$si_chef_men %>%
  as.character() %>%
  fct_recode(
    "femme du chef de ménage" = "1",
    "chef de ménage" = "2",
    "fils-fille du chef de ménage" = "3" , 
    "Autres" = "99"
  )

irec(base_tp2$ethnie)
## Recodage de base_tp2$ethnie en base_tp2$ethnie_rec
base_tp2$ethnie <- base_tp2$ethnie %>%
  as.character() %>%
  fct_recode(
    "Wolof" = "1",
    "Pulaar/toucouleur" = "2",
    "Sérère" = "3",
    "Mandika / Bambara" = "4",
    "Soninké" = "5",
    "Diola" = "6",
    "Manjack" = "7" , 
    "Bainouk" = "8" , 
    "Maures" = "9" , 
    "Balante" = "10",
    "Autre" = "77"
  )

irec(base_tp2$occupation)
irec(base_tp2$formation)
## Recodage de base_tp2$formation en base_tp2$formation_rec
base_tp2$formation <- base_tp2$formation %>%
  as.character() %>%
  fct_recode(
    "Non scolarisé" = "1",
    "Elémentaire" = "2",
    "Moyen" = "3",
    "Secondaire" = "4",
    "Licence" = "5",
    "Master" = "6" , 
    "Doctorat" = "7",
    "Ne sait pas" = "99"
  )

irec(base_tp2$niveau_alphabs)
## Recodage de base_tp2$niveau_alphabs en base_tp2$niveau_alphabs_rec
base_tp2$niveau_alphabs <- base_tp2$niveau_alphabs %>%
  as.character() %>%
  fct_recode(
    "Sans niveau" = "0",
    "Sait lire dans une langue" = "1",
    "Sait lire et écrire dans une langue" = "2"
  )

irec(base_tp2$types_varietes)
## Recodage de base_tp2$types_varietes en base_tp2$types_varietes_rec
base_tp2$types_varietes <- base_tp2$types_varietes %>%
  fct_recode(
    "Traditionnelles" = "1",
    "Traditionnelles et ameliorées" = "1 2",
    "Améliorées" = "2"
  )

irec(base_tp2$criteres_var)
base_tp2$criteres_var <- base_tp2$criteres_var %>%
  fct_recode(
    "rendements élévés" = "1",
    "taille des graines" = "2",
    "résistantes aux maladies/ravageurs" = "3",
    "tolérantes aux sècheresses" = "4",
    "tolérantes aux inondations" = "5", 
    "Faible charge de travail" = "6" ,
    "Faibles quantités d'intrants" = "7",
    "facile à transformer" = "8",
    "Haute teneur en huile" = "9" , 
    "Haut rendement après transformation" = "10" , 
    "Demande sur le marché" = "11" , 
    "Bon goût" = "12", 
    "Belle couleur" = "13" , 
    "Haut rendement en fourrages" = "14", 
    "Qualité du fourrage" = "15", 
    "autres à pécifier" = "16"
  )

base_tp2 <-base_tp2%>%
  rename(
    `rendements élévés` = criteres_var_1,
    `taille des graines` = criteres_var_2,
    `résistantes aux maladies/ravageurs` = criteres_var_3,
    `tolérantes aux sècheresses` = criteres_var_4,
    `tolérantes aux inondations` = criteres_var_5, 
    `Faible charge de travail` = criteres_var_6 ,
    `Faibles quantités d'intrants` = criteres_var_7 ,
    `facile à transformer` = criteres_var_8,
    `Haute teneur en huile` =  criteres_var_9, 
    `Haut rendement après transformation` = criteres_var_10 , 
    `Demande sur le marché` = criteres_var_11, 
    `Bon goût` = criteres_var_12, 
    `Belle couleur` =  criteres_var_13, 
    `Haut rendement en fourrages` = criteres_var_14, 
    `Qualité du fourrage` = criteres_var_15, 
    `autres à pécifier` = criteres_var_16
  )
    