# Chargement des packages----

library(tidyverse)
library(readxl)
library(questionr)

# IMPORTATION ET MISE EN FORME----
# Importation
projet <- read_excel("Données/Base_Projet.xlsx") 

# Donner le nombre de lignes et de colonnes de la base "projet"
nb_lignes <- nrow(projet)
nb_colonnes <- ncol(projet)
cat("Nombre de lignes de la base est :", nb_lignes, "\n")
cat("Nombre de colonnes de la base est :", nb_colonnes, "\n")

# Vérification de la présence des valeurs manquantes pour la variable "key"

valeurs_manquantes <- sum(is.na(projet$key)) # permet de compter le nombre de valeurs manquantes pour la variable key
  
if (valeurs_manquantes > 0) {
    cat("Il y a", valeurs_manquantes, "valeurs manquantes pour la variable 'key'.\n")
    PME_manquantes <- projet$PME[is.na(projet$key)]
    cat("Les PME concernées sont :", PME_manquantes, "\n")
  } else {
    cat("Il n'y a pas de valeurs manquantes pour la variable 'key'.\n")
  } # affiche un message dans la quelle les (PME) concernée(s) sont identifiées s'il y a présence de valeurs manquantes dans la variable key. Dans le cas contraire, affiche qu'il n'y a pas de valeurs manquantes.



# CREATION DE VARIABLES----

projet <- projet %>%
  rename(region = q1,
         departement = q2,
         sexe = q23) # pour renommer les variables q1, q2, et q23.

head(projet) # Afficher les premières lignes du data.frame pour vérifier les changements


projet <- projet %>%
  mutate(sexe_2 = ifelse(sexe == "Femme", 1, 0)) # nous avons crée la variable sexe_2 à l'aide de la fonction mutate du package dplyr combinée avec la fonction if/else intégré dans R

head(projet$sexe_2) # Afficher les premières lignes du data.frame pour vérifier si la création de la variable sexe_2 est effective


# Créer le data.frame langues
langues <- projet %>%
  select(key, starts_with("q24a_")) # nous avons selectionnée les variables de notre base commencant par q24a_ à l'aide de la fonction select du package dplyr et nous les avons mis dans un objet (data.frame) langues 

head(langues) # pour voir les premieres lignes du data frame langues

# Créer la variable "parle"

langues$parle = rowSums(langues[,2:10]) # nous avons crée une nouvelle variable (parle) dans le data frame (langues) qui est égale à la somme des langues parlées (comme les modalités des langues parlées sont 0 et 1 donc la somme donne le nombre de langues parlées) 
head(langues) # pour voir si la creation de la nouvelle variable est effective


# Sélectionner les variables "key" et "parle" dans le data frame langues

langues <- langues %>%
  select(key, parle) # avec la fonction select du package dplyr nous selectionnons juste les deux variables key et parle dans (langue)

head(langues) # permet de voir si la selection est effective

# Fusionner les data.frames projet et langues

projet_langues <- merge(projet, langues, by = "key") # merge est une fonction de R qui permet de fusionner deux bases de données selon une variable clé de fusion dans notre cas la clé c'est key
head(projet_langues)

# ANALYSES DESCRIPTIVES 

pl = projet_langues

# renommer les variables 

pl <- pl %>%
  rename(niv_ins = q25,
         stat_jur = q12,
         pro_loc = q81
         )
# pour le sexe

table(pl$sexe)
freq(pl$sexe, total = T)
barplot(table(pl$sexe))



# pour le niveau d'instruction

table(pl$niv_ins)
freq(pl$niv_ins, total = T, sort = "dec")
barplot(sort(table(pl$niv_ins)))



# pour le statut juridique

table(pl$stat_jur)
freq(pl$stat_jur, total = T, sort = "dec")
barplot(sort(table(pl$stat_jur)))
dotchart(sort(table(pl$stat_jur)))


# pour la propriété

table(pl$pro_loc)
freq(pl$pro_loc, total = T)
barplot(table(pl$pro_loc))


# pour le statut juridique et le sexe

table(pl$stat_jur, pl$sexe)
cprop(table(pl$stat_jur, pl$sexe))


# pour le niveau d'instruction et le sexe

table(pl$niv_ins, pl$sexe)
cprop(table(pl$niv_ins, pl$sexe))


# pour la propriété et le sexe

table(pl$pro_loc, pl$sexe)
cprop(table(pl$pro_loc, pl$sexe))


# Fonction univarie pour les statistiques descriptives univariées
univarie <- function(data, variable, ...) {
  descriptives <- summary(data[[variable]], ...)
  return(descriptives)
}

# Fonction bivarie pour les statistiques descriptives bivariées
bivarie <- function(data, var1, var2, plot = TRUE, ...) {
  if (is.numeric(data[[var1]]) & is.numeric(data[[var2]])) {
    correlation <- cor(data[[var1]], data[[var2]])
    if (plot) {
      plot(data[[var1]], data[[var2]], main = paste("Relation entre", var1, "et", var2), ...)
    }
    return(correlation)
  } else {
    table <- table(data[[var1]], data[[var2]])
    return(table)
  }
}


# Statistiques univariées pour la variable "region" avec les options supplémentaires
univarie(projet, "region", na.rm = TRUE)

# Statistiques bivariées pour les variables "region" et "parle" sans tracer de nuage de points
bivarie(projet, "region", "parle", plot = FALSE)

