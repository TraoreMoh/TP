#chargement des packages ----

library(tidyverse)
library(readxl)

#importation et mise en forme de la base ----

projet <- read_excel("Données/Base_Projet.xlsx")
View(projet)

dim(projet)

str(projet)

is.na(projet$key)

sum(is.na(projet$key))

#creation de variable----

dplyr::rename(projet, region = q1, departement = q2, sexe = q23)

# pour sexe_2 
projet <- mutate(
  projet,
 if (sexe == "Femme" ) {  sexe_2 = 1} else { sexe_2 = 0} )
# pour sexe 2

projet = mutate(projet,
                sexe_2 = case_when(
                  sexe == "Femme" ~ "1",
                  sexe != "Femme" ~ "0",
                  T ~"Autre"
                ))
# data.frame

langue = select(projet, key, sexe, sexe_2)

# pour mes graphiques

ggplot(pl) + geom_bar(aes(x = sexe))

ggplot(pl) + geom_bar(aes(x = niv_ins))

s = as.data.frame(table(pl$stat_jur))
s <- s %>%
  rename(stat_jur = Var1,
         n = Freq )
ggplot(s) + geom_col(aes(x = n, y = stat_jur))

ggplot(pl) + geom_bar(aes(x = pro_loc))


